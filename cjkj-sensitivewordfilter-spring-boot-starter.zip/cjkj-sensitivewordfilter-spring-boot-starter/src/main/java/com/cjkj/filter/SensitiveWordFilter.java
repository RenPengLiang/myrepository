package com.cjkj.filter;

import lombok.Data;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;


/**
 * @Author : RenPL
 * @Description: 敏感词过滤 工具类
 * @Date : 2020/2/24  09:23
 */
@Data
public class SensitiveWordFilter {

    private StringBuilder replaceAll;
    private String encoding = "UTF-8";
    private String replaceStr = "*";
    private int replaceSize = 500;
    private String fileName = "CensorWords.txt";
    private List<String> arrayList;

    public SensitiveWordFilter() {
        initializationWork();
    }

    /**
     * @param str 将要被过滤信息
     * @return 过滤后的信息
     */
    public String filterInfo(String str) {
        StringBuilder buffer = new StringBuilder(str);
        HashMap<Integer, Integer> hash = new HashMap<Integer, Integer>(arrayList.size());
        String temp;
        for (int x = 0; x < arrayList.size(); x++) {
            temp = arrayList.get(x);
            int findIndexSize = 0;
            for (int start = -1; (start = buffer.indexOf(temp, findIndexSize)) > -1; ) {
                //从已找到的后面开始找
                findIndexSize = start + temp.length();
                //起始位置
                Integer mapStart = hash.get(start);
                //满足1个，即可更新map
                if (mapStart == null || (mapStart != null && findIndexSize > mapStart)) {
                    hash.put(start, findIndexSize);
                }
            }
        }
        Collection<Integer> values = hash.keySet();
        for (Integer startIndex : values) {
            Integer endIndex = hash.get(startIndex);
            buffer.replace(startIndex, endIndex, replaceAll.substring(0, endIndex - startIndex));
        }
        hash.clear();
        return buffer.toString();
    }

    /**
     * 初始化敏感词库
     */
    public void initializationWork() {
        replaceAll = new StringBuilder(replaceSize);
        for (int x = 0; x < replaceSize; x++) {
            replaceAll.append(replaceStr);
        }
        //加载词库
        arrayList = new ArrayList<String>();
        InputStreamReader read = null;
        BufferedReader bufferedReader = null;
        try {
            read = new InputStreamReader(SensitiveWordFilter.class.getClassLoader().getResourceAsStream(fileName), encoding);
            bufferedReader = new BufferedReader(read);
            for (String txt = null; (txt = bufferedReader.readLine()) != null; ) {
                if (!arrayList.contains(txt)) {
                    arrayList.add(txt);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("初始化敏感词库", e);
        } finally {
            try {
                if (null != bufferedReader) {
                    bufferedReader.close();
                }
            } catch (IOException e) {
                // 流关闭异常
            }
            try {
                if (null != read) {
                    read.close();
                }
            } catch (IOException e) {
                // 流关闭异常
            }
        }
    }
}
