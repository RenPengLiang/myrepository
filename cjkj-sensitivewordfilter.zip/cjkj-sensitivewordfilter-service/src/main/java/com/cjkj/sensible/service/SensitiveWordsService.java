package com.cjkj.sensible.service;

import com.cjkj.common.model.PageData;
import com.cjkj.common.service.ISuperService;
import com.cjkj.sensible.dto.req.SensitiveWordsReq;
import com.cjkj.sensible.entity.SensitiveWordsEntity;

/**
 * @author RenPL
 * @Description: 敏感词管理service
 * @date 2020/2/24 9:14
 */
public interface SensitiveWordsService extends ISuperService<SensitiveWordsEntity> {

    /**
     * 分页查询
     *
     * @param sensitiveWordsReq
     * @return
     */
    PageData<SensitiveWordsEntity> listSensitiveWords(SensitiveWordsReq sensitiveWordsReq);
}
