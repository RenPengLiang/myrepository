package com.cjkj.sensible.dto.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * Description：敏感词查询请求实体
 *
 * @author RenPL
 * @date 2020-2-24 11:11:11
 */
@ApiModel(value = "敏感词查询请求实体")
@Data
public class SensitiveWordsReq extends BasePageRequest{

    @ApiModelProperty(name = "id", value = "主键")
    private Long id;

    @ApiModelProperty(name = "type", value = "敏感词类型")
    private String type;

    @ApiModelProperty(name = "content", value = "敏感词")
    private String content;

    @ApiModelProperty(name = "startCreateTime", value = "起始创建时间")
    private Date startCreateTime;

    @ApiModelProperty(name = "endCreateTime", value = "结束创建时间")
    private Date endCreateTime;

    @ApiModelProperty(name = "startUpdateTime", value = "起始修改时间")
    private Date startUpdateTime;

    @ApiModelProperty(name = "endUpdateTime", value = "结束修改时间")
    private Date endUpdateTime;

    @ApiModelProperty(name = "operator", value = "操作人")
    private String operator;

}
