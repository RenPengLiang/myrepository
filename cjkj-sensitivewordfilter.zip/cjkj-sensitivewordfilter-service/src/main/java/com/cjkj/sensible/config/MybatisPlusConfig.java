package com.cjkj.sensible.config;

import com.cjkj.common.config.DefaultMybatisPlusConfig;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * MybatisPlus配置
 * @date 2019-12-24 11:11:11
 * @author cjwl56
 */
@Configuration
@MapperScan({"com.cjkj.sensible.dao*"})
public class MybatisPlusConfig extends DefaultMybatisPlusConfig {

}
