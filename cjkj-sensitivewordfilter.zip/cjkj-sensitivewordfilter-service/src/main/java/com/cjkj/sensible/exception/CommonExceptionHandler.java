package com.cjkj.sensible.exception;

import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.cjkj.common.exception.GlobalExceptionAdvice;

/**
 * @ClassName CommonExceptionHandler
 * @Description 系统异常处理类，将系统异常统一格式化为系统JSON格式
 * @Author LJL
 * @Date 2019/07/03
 * @Version v1.0
 **/
@RestControllerAdvice
public class CommonExceptionHandler extends GlobalExceptionAdvice {

}
