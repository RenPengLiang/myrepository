package com.cjkj.sensible.controller;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cjkj.common.model.PageData;
import com.cjkj.common.model.ResultData;
import com.cjkj.common.enums.ReturnMsgEnum;
import com.cjkj.sensible.converter.SensitiveWordsConverter;
import com.cjkj.sensible.dto.req.SensitiveWordsReq;
import com.cjkj.sensible.dto.resp.SensitiveWordsRep;
import com.cjkj.sensible.entity.SensitiveWordsEntity;
import com.cjkj.sensible.service.SensitiveWordsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * @author RenPL
 * @Description: 敏感词管理
 * @date 2020/2/24 9:14
 */
@Slf4j
@RestController
@RequestMapping("sensible")
@RestControllerAdvice
@Api(value = "SensitiveWordsFilterController", tags = "敏感词管理")
public class SensitiveWordsController {

    @Autowired
    private SensitiveWordsService sensitiveWordsService;

    /**
     * 新增敏感词
     *
     * @param sensitiveWordsReq
     * @return
     */
    @PostMapping("/addSensitiveWords")
    @ApiOperation(value = "新增敏感词", notes = "\t  参数为对象json数据")
    public ResultData<String> addSensitiveWords(@RequestBody SensitiveWordsReq sensitiveWordsReq) {
        SensitiveWordsEntity entity = SensitiveWordsConverter.fromReqToEntity(sensitiveWordsReq);
        entity.setCreateTime(new Date());
        entity.setUpdateTime(null);
        if (sensitiveWordsService.save(entity)) {
            return ResultData.ok(ReturnMsgEnum.SUCCESS.getMsg());
        }
        return ResultData.failed("fail");

    }

    @PostMapping("/deleteSensitiveWords")
    @ApiOperation(value = "根据主键删除对应的敏感词信息", notes = "\t 根据主键删除对应的敏感词信息")
    public ResultData<JSONObject> deleteSensitiveWords(@RequestBody SensitiveWordsReq sensitiveWordsReq) {
        if (sensitiveWordsReq.getId() == null) {
            return ResultData.failed("参数错误");
        }
        if (sensitiveWordsService.removeById(sensitiveWordsReq.getId())) {
            return ResultData.ok(ReturnMsgEnum.SUCCESS.getMsg());
        }
        return ResultData.failed("fail");
    }

    /**
     * 修改敏感词
     *
     * @param )
     * @return
     */
    @PostMapping("/updateSensitiveWords")
    @ApiOperation(value = "修改敏感词", notes = "\t  参数为对象json数据")
    public ResultData updateSensitiveWords(@RequestBody SensitiveWordsReq sensitiveWordsReq) {
        SensitiveWordsEntity entity = SensitiveWordsConverter.fromReqToEntity(sensitiveWordsReq);
        entity.setCreateTime(null);
        entity.setUpdateTime(new Date());
        if (sensitiveWordsService.updateById(entity)) {
            return ResultData.ok(ReturnMsgEnum.SUCCESS.getMsg());
        }
        return ResultData.failed("fail");

    }

    @PostMapping("/getSensitiveWords")
    @ApiOperation(value = "根据主键查询对应的敏感词信息", notes = "\t 根据主键查询对应的敏感词信息")
    public ResultData<SensitiveWordsRep> getSensitiveWords(@RequestBody SensitiveWordsReq sensitiveWordsReq) {
        if (sensitiveWordsReq.getId() == null) {
            return ResultData.failed("参数错误");
        }
        return ResultData.ok(SensitiveWordsConverter.fromEntityToRep(sensitiveWordsService.getById(sensitiveWordsReq.getId())));
    }

    @PostMapping("/listSensitiveWords")
    @ApiOperation(value = "列表查询", notes = "\t 参数为对象json数据")
    public  ResultData<PageData<SensitiveWordsEntity>> listSensitiveWords(@RequestBody SensitiveWordsReq sensitiveWordsReq) {
        return ResultData.ok(sensitiveWordsService.listSensitiveWords(sensitiveWordsReq));
    }
}
