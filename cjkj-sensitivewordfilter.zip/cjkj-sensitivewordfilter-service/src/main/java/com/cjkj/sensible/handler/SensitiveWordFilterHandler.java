package com.cjkj.sensible.handler;

import com.cjkj.sensible.entity.SensitiveWordsEntity;
import com.cjkj.sensible.service.SensitiveWordsService;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

/**
 * @Author : RenPL
 * @Description: 敏感词过滤处理器
 * @Date : 2020/2/24  09:23
 */
@Component
public class SensitiveWordFilterHandler implements InitializingBean {

    private StringBuffer replaceAll;
    private String replaceStr = "*";
    private int replaceSize = 500;
    private List<String> arrayList;
    @Autowired
    private SensitiveWordsService sensitiveWordsService;

    /**
     * @param str 将要被过滤信息
     * @return 过滤后的信息
     */
    public String filterWords(String str) {
        StringBuffer buffer = new StringBuffer(str);
        HashMap<Integer, Integer> hash = new HashMap<Integer, Integer>(arrayList.size());
        String temp;
        for (int x = 0; x < arrayList.size(); x++) {
            temp = arrayList.get(x);
            int findIndexSize = 0;
            for (int start = -1; (start = buffer.indexOf(temp, findIndexSize)) > -1; ) {
                //从已找到的后面开始找
                findIndexSize = start + temp.length();
                //起始位置
                Integer mapStart = hash.get(start);
                //满足1个，即可更新map
                if (mapStart == null || (mapStart != null && findIndexSize > mapStart)) {
                    hash.put(start, findIndexSize);
                }
            }
        }
        Collection<Integer> values = hash.keySet();
        for (Integer startIndex : values) {
            Integer endIndex = hash.get(startIndex);
            buffer.replace(startIndex, endIndex, replaceAll.substring(0, endIndex - startIndex));
        }
        hash.clear();
        return buffer.toString();
    }

    /**
     * 初始化敏感词库
     */
    public synchronized void initializationWork() {
        if (replaceAll == null) {
            replaceAll = new StringBuffer(replaceSize);
        } else {
            replaceAll.delete(0, replaceAll.length());
        }
        for (int x = 0; x < replaceSize; x++) {
            replaceAll.append(replaceStr);
        }
        //加载词库
        if (arrayList == null) {
            arrayList = new ArrayList<>();
        } else {
            arrayList.clear();
        }
        try {
            List<SensitiveWordsEntity> listInfo = sensitiveWordsService.list();
            for (SensitiveWordsEntity entity : listInfo) {
                if (!arrayList.contains(entity.getContent())) {
                    arrayList.add(entity.getContent());
                }
            }
        } catch (Exception e) {
            throw new RuntimeException("初始化敏感词库", e);
        }
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        initializationWork();
    }
}
