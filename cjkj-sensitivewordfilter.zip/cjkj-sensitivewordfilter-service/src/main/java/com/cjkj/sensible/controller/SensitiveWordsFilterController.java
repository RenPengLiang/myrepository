package com.cjkj.sensible.controller;

import com.cjkj.common.model.ResultData;
import com.cjkj.sensible.handler.SensitiveWordFilterHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author RenPL
 * @Description: 敏感词过滤管理
 * @date 2020/2/24 9:14
 */
@Slf4j
@RestController
@RequestMapping("sensible")
@RestControllerAdvice
@Api(value = "SensitiveWordsFilterController", tags = "敏感词过滤管理")
public class SensitiveWordsFilterController {

    @Autowired
    private SensitiveWordFilterHandler sensitiveWordFilterHandler;

    @PostMapping("/filterWords")
    @ApiOperation(value = "调用工具类过滤文本敏感词", notes = "\t 调用工具类过滤文本敏感词")
    public ResultData<String> filterWords(@RequestBody String str) {
        if (StringUtils.isNotEmpty(str)) {
            return ResultData.ok(sensitiveWordFilterHandler.filterWords(str));
        }
        return ResultData.ok(str);
    }

    @PostMapping("/initializationWork")
    @ApiOperation(value = "刷新缓存接口", notes = "\t 刷新缓存接口：前端添加，删除，修改敏感信息后调用此接口刷新缓存")
    public ResultData<String> initializationWork() {
        sensitiveWordFilterHandler.initializationWork();
        return ResultData.ok("刷新成功!");
    }

}
