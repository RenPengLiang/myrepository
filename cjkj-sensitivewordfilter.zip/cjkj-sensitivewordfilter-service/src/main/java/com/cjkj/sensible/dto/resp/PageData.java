package com.cjkj.sensible.dto.resp;

import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * @Description 分页列表
 * @Author RenPL
 * @Date 2019/6/24 18:31
 **/
@Data
@Builder
public class PageData<T>{

    private long total;
    private List<T> list;

    public PageData() {
    }

    public PageData(long total, List<T> list) {
        this.total = total;
        this.list = list;
    }
}
