package com.cjkj.sensible.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cjkj.common.model.PageData;
import com.cjkj.common.service.impl.SuperServiceImpl;
import com.cjkj.sensible.converter.SensitiveWordsConverter;
import com.cjkj.sensible.dao.SensitiveWordsDao;
import com.cjkj.sensible.dto.req.SensitiveWordsReq;
import com.cjkj.sensible.entity.SensitiveWordsEntity;
import com.cjkj.sensible.service.SensitiveWordsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * @author RenPL
 * @Description: 敏感词管理service实现
 * @date 2020/2/24 9:14
 */
@Service
@Slf4j
public class SensitiveWordsServiceImpl extends SuperServiceImpl<SensitiveWordsDao, SensitiveWordsEntity> implements SensitiveWordsService {

    @Override
    public PageData<SensitiveWordsEntity> listSensitiveWords(SensitiveWordsReq sensitiveWordsReq) {
        Page<SensitiveWordsEntity> page= new Page<>();
        page.setSize(sensitiveWordsReq.getPageSize());
        page.setCurrent(sensitiveWordsReq.getPageNo());
        QueryWrapper<SensitiveWordsEntity> queryWrapper = SensitiveWordsConverter.fromQueryToWrapper(sensitiveWordsReq);
        queryWrapper.orderByDesc("id");
        return super.getPage(page, queryWrapper);
    }
}
