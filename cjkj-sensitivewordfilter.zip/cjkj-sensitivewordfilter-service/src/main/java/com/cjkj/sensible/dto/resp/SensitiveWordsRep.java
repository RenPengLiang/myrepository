package com.cjkj.sensible.dto.resp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * Description：敏感词响应信息封装实体
 *
 * @author RenPL
 * @date 2019-2-24 11:11:11
 */
@ApiModel(value = "敏感词响应信息封装实体")
@Data
public class SensitiveWordsRep {

    @ApiModelProperty(name = "id", value = "主键")
    private Long id;

    @ApiModelProperty(name = "type", value = "敏感词类型")
    private String type;

    @ApiModelProperty(name = "content", value = "敏感词")
    private String content;

    @ApiModelProperty(name = "createTime", value = "创建时间")
    private Date createTime;

    @ApiModelProperty(name = "updateTime", value = "修改时间")
    private Date updateTime;

    @ApiModelProperty(name = "operator", value = "操作人")
    private String operator;

}
