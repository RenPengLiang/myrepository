package com.cjkj.sensible.utils;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * 各种方便功能
 *
 * @author RenPL
 */
public class LambdaUtils {

    /**
     * data 不为 null 时，执行后面的 lambda 代码
     *
     * @param data 数据
     * @param func 代码
     * @param <T>  数据类型
     * @param <R>  返回类型
     * @return data == null，返回 empty；data != null，返回执行结果
     */
    public static <T, R> Optional<R> callIfNotNull(T data, Function<T, R> func) {
        if (data != null) {
            return Optional.ofNullable(func.apply(data));
        } else {
            return Optional.empty();
        }
    }

    /**
     * data 不为 null 时，执行后面的 lambda 代码
     *
     * @param data 数据
     * @param func 代码
     * @param <T>  数据类型
     */
    public static <T> void runIfNotNull(T data, Consumer<T> func) {
        if (data != null) {
            func.accept(data);
        }
    }

    /**
     * data 不为空时，执行后面的 lambda 代码
     *
     * @param data 数据
     * @param func 代码
     * @param <T>  数据类型，基本就是 String
     */
    public static <T extends CharSequence> void runIfNotEmpty(T data, Consumer<T> func) {
        if (data != null && data.length() > 0) {
            func.accept(data);
        }
    }

    /**
     * data 不为 null 时，执行后面的 lambda 代码
     *
     * @param data 数据
     * @param func 代码
     * @param <T>  数据类型
     */
    public static <T> void runIfStringNotNull(T data, Consumer<T> func) {
        if (data != null&&data!="") {
            func.accept(data);
        }
    }

    /**
     * 将某种 key 翻译成对象，并塞回原列表。
     * 使用标准服务 list 方法的版本。
     * <p></p>
     * 示例用法：
     * <pre>
     * // 将运力详情 dto 塞入调度单 dto ，使用 where capacity_no in 条件查询，并塞回
     * final List<TspDispatchDocumentsDto> items = resp.getData().getItems();
     * LambdaUtils.translateKeyToObj(
     *     items,
     *     TspDispatchDocumentsDto::getCapacityNo,
     *     "capacity_no",
     *     tspCapacityService,
     *     TspCapacity::getCapacityNo,
     *     (origin, another) -> origin.setTspCapacityDto(TspCapacityConverter.fromEntityToDto(another))
     * );
     * </pre>
     *
     * @param originItems           原始列表
     * @param originKeyExtractor    key 提取器，作为 in 条件
     * @param keyName               查询 in 条件
     * @param queryService          查询服务，提供详情对象
     * @param anotherKeyExtractor   详情对象 key 提取器，必须与 originKeyExtractor 的结果对应
     * @param anotherToOriginPusher 将详情对象塞回原始对象的函数
     * @param <T> 原始对象类型
     * @param <K> Key 类型，大部分为 String
     * @param <R> 详情对象类型
     */
    public static <T, K, R> void translateKeyToObj(
            List<T> originItems,
            Function<T, K> originKeyExtractor,
            String keyName,
            IService<R> queryService,
            Function<R, K> anotherKeyExtractor,
            BiConsumer<T, R> anotherToOriginPusher
    ) {
        final List<K> keyList = originItems.stream()
                .map(originKeyExtractor)
                .collect(Collectors.toList());

        final QueryWrapper<R> queryWrapper = new QueryWrapper<>();
        queryWrapper.in(keyName, keyList);
        final List<R> list = queryService.list(queryWrapper);
        final Map<K, R> capacityMap = list.stream().collect(Collectors.toMap(anotherKeyExtractor, v -> v));

        originItems.forEach(origin ->
                Optional.ofNullable(capacityMap.get(originKeyExtractor.apply(origin)))
                        .ifPresent(another -> anotherToOriginPusher.accept(origin, another))
        );
    }

    /**
     * 将某种 key 翻译成对象，并塞回原列表。
     * 使用自定义查询的版本。
     *
     * @param originItems           原始列表
     * @param originKeyExtractor    key 提取器，作为 in 条件
     * @param queryFunction         查询方法，提供详情对象
     * @param anotherKeyExtractor   详情对象 key 提取器，必须与 originKeyExtractor 的结果对应
     * @param anotherToOriginPusher 将详情对象塞回原始对象的函数
     * @param <T> 原始对象类型
     * @param <K> Key 类型，大部分为 String
     * @param <R> 详情对象类型
     */
    public static <T, K, R> void translateKeyToObj(
            List<T> originItems,
            Function<T, K> originKeyExtractor,
            Function<List<K>, List<R>> queryFunction,
            Function<R, K> anotherKeyExtractor,
            BiConsumer<T, R> anotherToOriginPusher
    ) {
        final List<K> keyList = originItems.stream()
                .map(originKeyExtractor)
                .collect(Collectors.toList());

        final List<R> list = queryFunction.apply(keyList);
        final Map<K, R> capacityMap = list.stream().collect(Collectors.toMap(anotherKeyExtractor, v -> v));

        originItems.forEach(origin ->
                Optional.ofNullable(capacityMap.get(originKeyExtractor.apply(origin)))
                        .ifPresent(another -> anotherToOriginPusher.accept(origin, another))
        );
    }
}
