package com.cjkj.sensible.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.Data;

import java.util.Date;

/**
 * @author RenPL
 * Date: 2020/2/24 14:54
 * Description: 敏感字过滤实体类
 */
@Data
@TableName("t_sensitive_words")
public class SensitiveWordsEntity {

    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    @JsonSerialize(using = ToStringSerializer.class)
    private Long id;

    /**
     * 敏感词类型
     */
    @TableField("type")
    private String type;

    /**
     * 敏感词
     */
    @TableField("content")
    private String content;

    /**
     * 创建时间
     */
    @TableField("create_time")
    private Date createTime;

    /**
     * 修改时间
     */
    @TableField("update_time")
    private Date updateTime;

    /**
     * 操作人
     */
    @TableField("operator")
    private String operator;

}

