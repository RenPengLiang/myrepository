package com.cjkj.sensible.dto.req;

import lombok.Data;

import java.io.Serializable;

/**
 * Description：分页基类
 *
 * @author RenPL
 * @date 2019-2-24 11:11:11
 */
@Data
public abstract class BasePageRequest implements Serializable {

    private static final int DEFAULT_PAGESIZE = 10;
    private static final int DEFAULT_PAGE_NO = 1;

    private Integer pageSize;
    private Integer pageNo;
    
}