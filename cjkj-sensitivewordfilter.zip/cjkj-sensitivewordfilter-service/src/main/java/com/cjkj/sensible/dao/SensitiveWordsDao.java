package com.cjkj.sensible.dao;

import com.cjkj.common.mapper.SuperMapper;
import com.cjkj.sensible.entity.SensitiveWordsEntity;
import org.springframework.stereotype.Repository;

/**
 * @author RenPL
 * @Description: 敏感词管理dao
 * @date 2020/2/24 9:14
 */
@Repository
public interface SensitiveWordsDao extends SuperMapper<SensitiveWordsEntity> {
}
