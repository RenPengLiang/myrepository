package com.cjkj.sensible.converter;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cjkj.sensible.dto.req.SensitiveWordsReq;
import com.cjkj.sensible.dto.resp.SensitiveWordsRep;
import com.cjkj.sensible.entity.SensitiveWordsEntity;
import com.cjkj.sensible.utils.LambdaUtils;
import org.springframework.beans.BeanUtils;

/**
 * 各类对象转换工具
 *
 * @author RenPL 2020-2-24
 */
public class SensitiveWordsConverter {
    /**
     * 将前端查询类转换为 MybatisPlus 查询类
     *
     * @param query 前端查询类
     * @return MybatisPlus 查询类
     */
    public static QueryWrapper<SensitiveWordsEntity> fromQueryToWrapper(SensitiveWordsReq query) {
        final QueryWrapper<SensitiveWordsEntity> wrapper = new QueryWrapper<>();
        // 敏感词类型
        LambdaUtils.runIfNotNull(query.getType(), v -> wrapper.eq("type", v));
        // 敏感词内容
        LambdaUtils.runIfNotEmpty(query.getContent(), v -> wrapper.eq("content", v));
        // 起始创建时间
        LambdaUtils.runIfNotNull(query.getStartCreateTime(), v -> wrapper.ge("create_time", v));
        // 结束创建时间
        LambdaUtils.runIfNotNull(query.getEndCreateTime(), v -> wrapper.le("create_time", v));
        // 起始修改时间
        LambdaUtils.runIfNotNull(query.getStartUpdateTime(), v -> wrapper.ge("update_time", v));
        // 结束修改时间
        LambdaUtils.runIfNotNull(query.getEndUpdateTime(), v -> wrapper.le("update_time", v));
        return wrapper;
    }

    /**
     * 数据库对象转换为 Rep
     *
     * @param entity 数据库对象
     * @return Rep
     */
    public static SensitiveWordsRep fromEntityToRep(SensitiveWordsEntity entity) {
        final SensitiveWordsRep dto = new SensitiveWordsRep();
        BeanUtils.copyProperties(entity, dto);
        return dto;
    }

    /**
     * 数据库对象转换为 Req
     *
     * @param req 对象
     * @return entity对象
     */
    public static SensitiveWordsEntity fromReqToEntity(SensitiveWordsReq req) {
        final SensitiveWordsEntity entity = new SensitiveWordsEntity();
        BeanUtils.copyProperties(req, entity);
        return entity;
    }
}
